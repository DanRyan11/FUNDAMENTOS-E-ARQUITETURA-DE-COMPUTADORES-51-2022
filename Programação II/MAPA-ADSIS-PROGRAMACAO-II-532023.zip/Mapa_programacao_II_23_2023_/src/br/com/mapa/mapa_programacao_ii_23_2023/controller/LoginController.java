/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.mapa.mapa_programacao_ii_23_2023.controller;

import br.com.mapa.mapa_programacao_ii_23_2023.dao.Conexao;
import br.com.mapa.mapa_programacao_ii_23_2023.dao.LoginDAO;
import br.com.mapa.mapa_programacao_ii_23_2023.view.ViewLogin;
import br.com.mapa.mapa_programacao_ii_23_2023.view.ViewSignUp;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Danilo Ryan
 */
public class LoginController {

    public void cadastroUsuario(ViewSignUp view) throws SQLException {
        Connection conexao = new Conexao().getConnection();
        LoginDAO cadastro = new LoginDAO();

        cadastro.cadastrarUsuario(
                view.getUserNameText().getText(),
                view.getUserNicknameText().getText(),
                view.getUserPassword().getText(),
                view.getUserEmailText().getText()
        );
    }

    public void logarUsuario(ViewLogin view) throws SQLException, Exception {
        Connection conexao = new Conexao().getConnection();
        LoginDAO cadastro = new LoginDAO();

        if (!cadastro.isUsuarioValido(
                view.getUserLoginText().getText(),
                view.getUserLoginPassword().getText()
        )) {
            throw new Exception("Usuário Inválido");
        }
    }

}
