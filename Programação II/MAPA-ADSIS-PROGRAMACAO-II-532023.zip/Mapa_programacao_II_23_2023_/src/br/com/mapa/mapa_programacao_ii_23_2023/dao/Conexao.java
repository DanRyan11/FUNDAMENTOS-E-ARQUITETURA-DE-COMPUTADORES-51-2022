package br.com.mapa.mapa_programacao_ii_23_2023.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Danilo Ryan
 */
public class Conexao {

    public Connection getConnection() {
        Connection conexao = null;

        try {
            String dbHost = "localhost";
            String dbPort = "5004";
            String dbName = "prosync_camara";
            String dbUsername = "painel_camara";
            String dbPassword = "ff2020ad4cee04b54cf07abae23aa963";

            String url = "jdbc:mysql://" + dbHost + ":" + dbPort + "/" + dbName;

            // Registrar o driver JDBC (apenas necessário uma vez)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Estabelecer a conexão
            conexao = DriverManager.getConnection(url, dbUsername, dbPassword);
        } catch (ClassNotFoundException e) {
            System.err.println("Erro ao carregar o driver JDBC: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
        }

        return conexao;
    }

}
