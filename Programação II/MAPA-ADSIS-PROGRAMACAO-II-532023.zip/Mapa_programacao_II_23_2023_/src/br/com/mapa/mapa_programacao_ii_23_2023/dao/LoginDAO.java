/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.mapa.mapa_programacao_ii_23_2023.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

/**
 *
 * @author Danilo Ryan
 */
public class LoginDAO {

    public void cadastrarUsuario(String nome, String usuario, String senha, String email) throws SQLException {
        Connection conexao = new Conexao().getConnection();
        String sqlInsertUsuario = "insert into usuario(nome, login, senha, email) values (?,?,?,?)";
        PreparedStatement inserirUsuarioState = conexao.prepareStatement(sqlInsertUsuario);

        inserirUsuarioState.setString(1, nome);
        inserirUsuarioState.setString(2, usuario);
        inserirUsuarioState.setString(3, senha);
        inserirUsuarioState.setString(4, email);

        inserirUsuarioState.execute();
        inserirUsuarioState.close();

    }

public boolean isUsuarioValido(String usuario, String senha) throws SQLException {

    Connection conexao = new Conexao().getConnection();

    String sqlSelectUsuario = "SELECT id, nome, login, email FROM usuario WHERE login = ? AND senha = ?";

    PreparedStatement selectUsuarioState = conexao.prepareStatement(sqlSelectUsuario);

    selectUsuarioState.setString(1, usuario);
    selectUsuarioState.setString(2, senha);

    ResultSet resultSet = selectUsuarioState.executeQuery();

    boolean isValid = resultSet.next();

    resultSet.close();
    selectUsuarioState.close();

    return isValid;
}
}
