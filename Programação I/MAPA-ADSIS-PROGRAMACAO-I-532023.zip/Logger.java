public class Logger {
  public static void showBlocResult(String[] resultados) {
      System.out.println("--------------------------");
      for (String value : resultados) {
          System.out.println(value);
      }
      System.out.println("--------------------------");
    }

    public static void printSuccess(String message) {
      System.out.println("\u001B[32m" + message + "\u001B[0m"); // Cor verde
    }

    public static void printError(String message) {
      System.out.println("\u001B[31m" + message + "\u001B[0m"); // Cor vermelha
    }

    public static void printWarning(String message) {
      System.out.println("\u001B[33m" + message + "\u001B[0m"); // Cor amarela
    }

    public static void printNormal(String message) {
      System.out.println(message);
    }
  
}
