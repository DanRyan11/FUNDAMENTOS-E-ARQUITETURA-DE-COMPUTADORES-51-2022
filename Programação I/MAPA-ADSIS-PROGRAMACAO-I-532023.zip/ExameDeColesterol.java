import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

public class ExameDeColesterol extends Exame {

    private float ldlLevelMgL;
    private float hdlLevelMgL;
    private String pacientRisk;
  
    public ExameDeColesterol(Paciente paciente) {
        super(paciente);
    }

    public void registrarExame() {
        ldlLevelMgL = InputReader.readNumber("Digite o nível de LDL (mg/L)");
        setLdlLevelMgL(ldlLevelMgL);

        hdlLevelMgL = InputReader.readNumber("Digite o nível de HDL (mg/L)");
        setHdlLevelMgL(hdlLevelMgL);

      List<String> riskValues = new ArrayList<>(Arrays.asList("A","M","B"));
        String tipoSanguineo = InputReader.readEnum("Digite o risco do paciente (A - Alto, M - Médio, B - Baixo)", riskValues);
        setPacientRisk(tipoSanguineo);
    }

    public void showResultados() {
        Logger.showBlocResult(new String[]{
            "EXAME de Colesterol",
            "Resultado LDL: " + getLdlLevelMgL() + " mg/L\n",
            "Resultado HDL: " + getHdlLevelMgL() + " mg/L\n",
            "Classificação: " + getResultados() + "\n"
        });
    }

    // setters

    public void setLdlLevelMgL(float ldlLevelMgL) {
        this.ldlLevelMgL = ldlLevelMgL;
    }

    public void setHdlLevelMgL(float hdlLevelMgL) {
        this.hdlLevelMgL = hdlLevelMgL;
    }

    public void setPacientRisk(String pacientRisk) {
        this.pacientRisk = pacientRisk;
    }

    // getters

    public float getLdlLevelMgL() {
        return ldlLevelMgL;
    }

    public float getHdlLevelMgL() {
        return hdlLevelMgL;
    }

    public String getPacientRisk() {
        return pacientRisk;
    }

    public String getResultados() {
        int pacientAge = getPaciente().getIdade();
        float hdlLevel = getHdlLevelMgL();
        float ldlLevel = getLdlLevelMgL();
        String pacientRisk = getPacientRisk();
        String hdlStatus, ldlStatus;

        if (pacientAge < 20) {
            hdlStatus = hdlLevel > 45 ? "HDL - BOM" : "HDL - RUIM";
        } else {
            hdlStatus = hdlLevel > 40 ? "HDL - BOM" : "HDL - RUIM";
        }

        switch (pacientRisk) {
            case "B":
                ldlStatus = ldlLevel < 100 ? "LDL - BOM" : "LDL - RUIM";
                break;

            case "M":
                ldlStatus = ldlLevel < 70 ? "LDL - BOM" : "LDL - RUIM";
                break;

            case "A":
                ldlStatus = ldlLevel < 50 ? "LDL - BOM" : "LDL - RUIM";
                break;

            default:
                ldlStatus = "LDL - Desconhecido";
                break;
        }

        return "HDL: " + hdlStatus + " | LDL: " + ldlStatus + "\n";
    }
}
