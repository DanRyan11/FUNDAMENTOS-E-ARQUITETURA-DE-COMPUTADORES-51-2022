import java.util.Scanner;
import java.util.List;

import java.util.List; // Import the List class
import java.util.ArrayList; // Import ArrayList for creating a list

public class InputReader {
  private static Scanner scanner = new Scanner(System.in);

  public static String readString(String prompt) {
    System.out.print(prompt + ": ");
    return scanner.nextLine().trim();
  }
  
 public static int readNumber(String prompt) {
        while (true) {
            System.out.print(prompt + ": ");
            String input = scanner.nextLine().trim();

            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                Logger.printError("Valor inválido. Por favor, digite um número inteiro.");
            }
        }
    }

  public static String readEnum(String prompt, List<String> enumValues) {
    String enumValuesString = String.join(", ", enumValues);

    while (true) {
      System.out.print(prompt + " (" + enumValuesString + "): ");
      String input = scanner.nextLine().trim();

      if (enumValues.contains(input)) {
        return input;
      } else {
        Logger.printError("Valor inválido. Por favor, digite um dos valores: " + enumValuesString);
      }
    }
  }
}
