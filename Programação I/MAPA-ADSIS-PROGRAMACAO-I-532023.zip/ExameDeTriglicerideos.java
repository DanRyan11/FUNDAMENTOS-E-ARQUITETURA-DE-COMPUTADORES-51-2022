import java.util.List;

public class ExameDeTriglicerideos extends Exame {

    private int nivelTriglicerideosMgL;
    
    public ExameDeTriglicerideos(Paciente paciente) {
        super(paciente);
    }

    public void registrarExame() {
        nivelTriglicerideosMgL = InputReader.readNumber("Digite o nível de Triglicerídeos (mg/L)");
        definirNivelTriglicerideosMgL(nivelTriglicerideosMgL);
    }

    public void mostrarResultados() {
        Logger.showBlocResult(new String[]{
            "EXAME de Triglicerídeos",
            "Resultado Triglicerídeos: " + getNivelTriglicerideosMgL() + " mg/L\n",
            "Classificação: " + obterResultados() + "\n"
        });
    }

    // getters

    public int getNivelTriglicerideosMgL() {
        return nivelTriglicerideosMgL;
    }

    public String obterResultados() {
        int idadePaciente = getPaciente().getIdade();
        int nivelTriglicerideosMgL = getNivelTriglicerideosMgL();

        if (idadePaciente < 10) {
            return nivelTriglicerideosMgL < 75 ? "Bom" : "Ruim";
        }

        if (idadePaciente >= 10 && idadePaciente <= 19) {
            return nivelTriglicerideosMgL < 90 ? "Bom" : "Ruim";
        }

        if (idadePaciente >= 20) {
            return nivelTriglicerideosMgL < 150 ? "Bom" : "Ruim";
        }

        return "Resultado Desconhecido";
    }

    // setters

    public void definirNivelTriglicerideosMgL(int nivelTriglicerideosMgL) {
        this.nivelTriglicerideosMgL = nivelTriglicerideosMgL;
    }
}
