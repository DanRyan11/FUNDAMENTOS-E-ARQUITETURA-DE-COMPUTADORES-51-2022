import java.util.List;

public class ExameDeGlicemia extends Exame {
  
    public ExameDeGlicemia(Paciente paciente) {
        super(paciente);
    }

    private int glicoseNivelMgL;

    public void registrarExame() {
        glicoseNivelMgL = InputReader.readNumber("Digite o nível de glicose (mg/L)");
        setNivelGlicose(glicoseNivelMgL);
    }

    public void showResultados() {
        Logger.showBlocResult(new String[]{
            "EXAME de Glicemia",
            "Resultado Glicemia: " + getNivelGlicoseMgL() + " mg/L\n",
            "Classificação: " + getResultados() + "\n"
        });
    }

    // setters

    public void setNivelGlicose(int glicoseNivelMgL) {
        this.glicoseNivelMgL = glicoseNivelMgL;
    }

    // getters

    public int getNivelGlicoseMgL() {
        return glicoseNivelMgL;
    }

    public String getResultados() {
        if (glicoseNivelMgL < 100) {
            return "Normoglicemia";
        } else if (glicoseNivelMgL >= 100 && glicoseNivelMgL < 126) {
            return "Pré-diabetes";
        } else {
            return "Diabetes";
        }
    }
}
