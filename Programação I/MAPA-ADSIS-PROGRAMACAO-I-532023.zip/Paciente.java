import java.time.Year;

public class Paciente {

    private String nomePaciente;
    private int anoNascimento;
    private String tipoSanguineo;

    public Paciente(String nomePaciente, int anoNascimento, String tipoSanguineo) {
        this.nomePaciente = nomePaciente;
        this.anoNascimento = anoNascimento;
        this.tipoSanguineo = tipoSanguineo;
    }

    public String getNome() {
        return nomePaciente;
    }

    public int getAnoNascimento() {
        return anoNascimento;
    }

    public String getTipoSanguineo() {
        return tipoSanguineo;
    }

    public int getIdade() {
        int currentYear = Year.now().getValue();
        return currentYear - anoNascimento;
    }
}
