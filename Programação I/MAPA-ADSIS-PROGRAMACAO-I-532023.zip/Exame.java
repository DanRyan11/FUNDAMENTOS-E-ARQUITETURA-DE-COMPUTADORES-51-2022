public class Exame {
  private Paciente paciente;

  public Exame(Paciente paciente) {
    this.paciente = paciente;
  }

  public Paciente getPaciente() {
    return this.paciente;
  }

  public void registrarExame() {
  }

  public void showResultados() {
  }

  public String getResultados() {
    return null; 
  }
}