import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

public class BateriaDeExame {

    private Paciente paciente;

    public void registrarPaciente() {
        String nomePaciente = InputReader.readString("Digite o nome do paciente");

        int anoNascimento = InputReader.readNumber("Digite o ano de nascimento do paciente");

        // Example usage for readEnum
        List<String> tipoSanguineos = new ArrayList<>(Arrays.asList("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"));
        String tipoSanguineo = InputReader.readEnum("Digite o tipo sanguíneo do paciente", tipoSanguineos);
        
        paciente = new Paciente(nomePaciente, anoNascimento, tipoSanguineo);
    }

    public void fazerExames() {
        Paciente paciente = getPaciente();

        ExameDeGlicemia exameGlicemia = new ExameDeGlicemia(paciente);
        ExameDeColesterol exameColesterol = new ExameDeColesterol(paciente);
        ExameDeTriglicerideos exameTriglicerideos = new ExameDeTriglicerideos(paciente);

        Logger.printNormal("\nComeçando cadastro de exames\n");

        Logger.printNormal("Cadastrando exame de Glicemia");
        exameGlicemia.registrarExame();
        Logger.printSuccess("Cadastrado com sucesso o exame de Glicemia\n");

        Logger.printNormal("Cadastrando exame de Colesterol");
        exameColesterol.registrarExame();
        Logger.printSuccess("Cadastrado com sucesso o exame de Colesterol\n");

        Logger.printNormal("Cadastrando exame de Triglicerideos");
        exameTriglicerideos.registrarExame();
        Logger.printSuccess("Cadastrado com sucesso o exame de Triglicerideos\n");

        Logger.showBlocResult(new String[]{
            "PACIENTE\n",
            "Nome: " + paciente.getNome() + "\n",
            "Tipo Sanguíneo: " + paciente.getTipoSanguineo() + "\n",
            "Idade: " + paciente.getIdade() + "\n"
        });

        exameGlicemia.showResultados();
        exameColesterol.showResultados();
        exameTriglicerideos.showResultados();
    }

    // setters
    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    // getters
    public Paciente getPaciente() {
        return this.paciente;
    }

    public static void main(String[] args) {
        BateriaDeExame bateriaDeExames = new BateriaDeExame();
        bateriaDeExames.registrarPaciente();
        bateriaDeExames.fazerExames();
    }
}
